
import HomeView from "@/components/HomeView";

const App = () => {


  return (
   <>
 
  <HomeView/>
  </>
  );
};

export default App;
